/* Byte-preserving ABI adapter only. Gameplay and recording stay in the C++ module. */
function towerAdapter(core) {
  return Object.freeze({
    start_session(game,effects,seed) {
      const gameBytes=core.lengthBytesUTF8(game),effectsBytes=core.lengthBytesUTF8(effects);
      const args=gameBytes>262144 || effectsBytes>262144?['',0,'',0,-1]:[game,gameBytes,effects,effectsBytes,seed];
      return Boolean(core.ccall('tower_start','number',['string','number','string','number','number'],
        args));
    },
    advance(rotation,stone,shock) {
      return Boolean(core.ccall('tower_advance','number',['number','number','number'],[rotation,Number(stone),Number(shock)]));
    },
    snapshot:()=>core.ccall('tower_snapshot','string',[],[]),
    recording:()=>core.ccall('tower_recording','string',[],[]),
    verify_recording(text) {
      const size=core.lengthBytesUTF8(text);
      return core.ccall('tower_verify','number',['string','number'],size>2*1024*1024?['',-1]:[text,size]);
    },
    last_error:()=>core.ccall('tower_error','string',[],[])
  });
}
if(typeof window!=='undefined') {
  const base=new URL('.',document.currentScript.src);
  createTowerCore({locateFile:name=>new URL(name,base).href})
    .then(core=>{window.WalletCore=towerAdapter(core);})
    .catch(error=>{window.walletBootError=String(error);console.error(error);});
}
if(typeof module!=='undefined') module.exports=towerAdapter;
